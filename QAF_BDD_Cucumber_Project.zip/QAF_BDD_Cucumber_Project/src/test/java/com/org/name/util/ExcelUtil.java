package com.org.name.util;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

public class ExcelUtil {
    public ExcelUtil(){

    }
    public static List<Map<String,String>> getDataFromExcel(String dataFile,String sheetName,String key) throws IOException{
        //Path of the excel file
        FileInputStream fis =null;
        List<Map<String,String>> mapData=new ArrayList<>();
        try
        {
        fis = new FileInputStream(new File(dataFile));

//Creating a workbook
        XSSFWorkbook workbook = new XSSFWorkbook(fis);
        XSSFSheet sheet = workbook.getSheet(sheetName);
        Cell tableStart=getStartTable(key,sheet);
        if(tableStart == null){
            throw new RuntimeException();
        }
        int startRow=tableStart.getRowIndex();
        int startCol=tableStart.getColumnIndex();
        tableStart.getRow().getRowNum();
        Cell tableEnd=getEndTable(key,sheet);
        int endRow=tableEnd.getRowIndex();
        int endCol=tableEnd.getColumnIndex();
        int var10000=endRow-startRow;
        int numCols=endCol-(startCol+1);
        HashMap<String,String> headersMap=getHeaders(key,sheet);
        if(!headersMap.values().contains(ExcelUtilParams.runMode.name()) || !headersMap.values().contains(ExcelUtilParams.testCaseId.name())){

        }
        for(int i=startRow+1;i<=endRow;++i){
            HashMap<String,String> rowMap=new HashMap<>();
            Row row=sheet.getRow(i);

            for(int j=startCol+1;j<=endCol-1;++j){
                Cell cell=row.getCell(j);
                DataFormatter df=new DataFormatter();
                FormulaEvaluator evaluator=workbook.getCreationHelper().createFormulaEvaluator();
                String value=df.formatCellValue(cell,evaluator);
                rowMap.put((String)headersMap.get(String.valueOf(j)),value);
            }
            mapData.add(rowMap);
        }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                fis.close();
            }catch (Exception e){

            }
        }
        return mapData;
    }

    private static HashMap<String, String> getHeaders(String tableName, XSSFSheet sheet) {
        int tableStartCol=getStartTable(tableName,sheet).getRow().getFirstCellNum();
        int tableEndCol=getStartTable(tableName,sheet).getRow().getLastCellNum();
        Row headers=getStartTable(tableName,sheet).getRow();
        HashMap<String, String> headersMap=new HashMap<>();
        for(int i=tableStartCol+1;i<tableEndCol;++i){
            Cell cell=headers.getCell(i);
            DataFormatter df=new DataFormatter();
            String value=df.formatCellValue(cell);
            headersMap.put(String.valueOf(i),value);
        }
        return headersMap;
    }

    private static Cell getEndTable(String tableName, XSSFSheet sheet) {
        int tableStartCol=getStartTable(tableName,sheet).getRow().getFirstCellNum();
        int tableEndCol=getStartTable(tableName,sheet).getRow().getLastCellNum();
        Iterator ite=sheet.rowIterator();
        while(ite.hasNext()){
            Row row=(Row) ite.next();

            for(int i=tableStartCol+1; i<=tableEndCol+1;++i){
                Cell cell=row.getCell(i);
                DataFormatter df=new DataFormatter();
                String value=df.formatCellValue(cell);
                if(tableName.equalsIgnoreCase(value)){
                    return cell;
                }
            }


        }
        return null;
    }

    private static Cell getStartTable(String tableName, XSSFSheet sheet) {
        Iterator ite=sheet.rowIterator();
        while(ite.hasNext()){
            Row row=(Row) ite.next();
            Iterator<Cell> cite=row.cellIterator();

            while(cite.hasNext()){
                Cell cell=(Cell) cite.next();
                DataFormatter df=new DataFormatter();
                String value=df.formatCellValue(cell);
                if(tableName.equalsIgnoreCase(value)) {
                    return cell;
                }
            }
        }
        return null;
    }

    public static Object[][] getDataFromxlsx(String dataFile, String sheetName, String key) {
        Object[][] objecttoretun=null;
        List<Map<String,String>> bigMapData=null;
        try{
            bigMapData=getDataFromExcel(dataFile,sheetName,key);
        }catch (Exception e){
            e.printStackTrace();
        }
        objecttoretun=new Object[getRunModeMap(bigMapData).size()][1];
        for(int i=0;i<getRunModeMap(bigMapData).size();++i){
            if(((String) ((Map)getRunModeMap(bigMapData).get(i)).get(ExcelUtilParams.runMode.name())).equalsIgnoreCase(ExcelUtilParams.yes.name())){
                objecttoretun[i][0]=getRunModeMap(bigMapData).get(i);
            }
        }
        return objecttoretun;
    }

    private static List<Map<String, String>> getRunModeMap(List<Map<String, String>> bigMapData) {
        List<Map<String, String>> runModeMap=new ArrayList<>();
        for(int i=0;i<bigMapData.size();++i){
            if(((String) ((Map) bigMapData.get(i)).get(ExcelUtilParams.runMode.name())).equalsIgnoreCase(ExcelUtilParams.yes.name())){
                runModeMap.add((Map) bigMapData.get(i));
            }
        }
        return  runModeMap;
    }

    static enum ExcelUtilParams{
        dataFile,
        sheet,
        key,
        runMode,
        testCaseId,
        yes;

        private ExcelUtilParams(){

        }
    }
}
