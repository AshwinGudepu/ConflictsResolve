package com.org.name.listeners;

import com.qmetry.qaf.automation.step.QAFTestStepListener;
import com.qmetry.qaf.automation.step.StepExecutionTracker;
import org.testng.*;
import org.testng.internal.IResultListener;

public abstract class QAFListener implements IResultListener {

   public QAFListener(){
   }
}