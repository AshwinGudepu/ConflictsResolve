package com.org.name.listeners;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.TestBaseProvider;
import com.qmetry.qaf.automation.step.QAFTestStepListener;
import com.qmetry.qaf.automation.step.StepExecutionTracker;
import org.testng.*;

import java.util.Iterator;

public class TestListener extends QAFListener implements ISuiteListener, QAFTestStepListener, IInvokedMethodListener, IExecutionListener {


    public TestListener(){

    }
    public void beforeInvocation(IInvokedMethod method, ITestResult testResult){

    }
    public void afterInvocation(IInvokedMethod method, ITestResult testResult){
        Iterator keys=ConfigurationManager.getBundle().getKeys("driver");
        while(keys.hasNext()){
            String key= (String) keys.next();
            if(key.startsWith("driver.name")){
                String driverName=ConfigurationManager.getBundle().getString(key);
                try{
                    (TestBaseProvider.instance().get()).tearDown(driverName);
                }catch(Exception e){

                }
            }
        }
    }

    @Override
    public void onFailure(StepExecutionTracker stepExecutionTracker) {

    }

    @Override
    public void beforExecute(StepExecutionTracker stepExecutionTracker) {

    }

    @Override
    public void afterExecute(StepExecutionTracker stepExecutionTracker) {

    }

    @Override
    public void onConfigurationSuccess(ITestResult iTestResult) {

    }

    @Override
    public void onConfigurationFailure(ITestResult iTestResult) {

    }

    @Override
    public void onConfigurationSkip(ITestResult iTestResult) {

    }

    @Override
    public void onExecutionStart() {

    }

    @Override
    public void onExecutionFinish() {

    }

    @Override
    public void onStart(ISuite iSuite) {

    }

    @Override
    public void onFinish(ISuite iSuite) {

    }

    @Override
    public void onTestStart(ITestResult iTestResult) {

    }

    @Override
    public void onTestSuccess(ITestResult iTestResult) {

    }

    @Override
    public void onTestFailure(ITestResult iTestResult) {

    }

    @Override
    public void onTestSkipped(ITestResult iTestResult) {

    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {

    }

    @Override
    public void onStart(ITestContext iTestContext) {

    }

    @Override
    public void onFinish(ITestContext iTestContext) {

    }
}
