package com.org.name.pagelocators;

public interface GooglePageLocators {
    public static String TEXT_AREA = "{\"locator\":\"xpath=//textarea[@title='Search']\"}";
}
