package com.org.name.steps;

import com.org.name.pages.GooglePage;
import com.qmetry.qaf.automation.step.QAFTestStep;
import static com.qmetry.qaf.automation.step.CommonStep.get;

public class OpenGoogleSteps {

    @QAFTestStep(description="user navigates to Google home page")
    public void userNavigatesToGoogleHomePage(){
        get("/");
    }

    @QAFTestStep(description="user enter the text as {0}")
    public void userEnterTheTextAs(String txt){
        GooglePage googlePage = new GooglePage();
        googlePage.userEnterText(txt);
    }
}
