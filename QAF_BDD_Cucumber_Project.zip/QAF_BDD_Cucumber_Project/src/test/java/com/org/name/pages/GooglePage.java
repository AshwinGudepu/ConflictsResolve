package com.org.name.pages;

import com.org.name.pagelocators.GooglePageLocators;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class GooglePage extends WebDriverBaseTestPage<WebDriverTestPage> implements GooglePageLocators {
    @Override
    protected void openPage(PageLocator pageLocator, Object... objects) {
    }

    @FindBy(locator = TEXT_AREA)
    private QAFWebElement textAreaInput;

    public QAFWebElement getTextAreaInput() {
        return textAreaInput;
    }

    public void userEnterText(String text){
        getTestBase().getDriver().manage().deleteAllCookies();
        getTestBase().getDriver().manage().window().maximize();
        textAreaInput.waitForVisible(20000);
        textAreaInput.sendKeys(text);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

}
