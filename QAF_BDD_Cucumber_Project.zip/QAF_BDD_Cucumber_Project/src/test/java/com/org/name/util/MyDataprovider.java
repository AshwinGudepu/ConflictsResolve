package com.org.name.util;

import com.qmetry.qaf.automation.core.AutomationError;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.step.client.TestNGScenario;
import org.testng.ITestNGMethod;
import org.testng.annotations.DataProvider;

import java.util.Map;

public class MyDataprovider {
    public MyDataprovider(){

    }
    @DataProvider(
            name="dp-for-excel"
    )
    public static Object[][] dataProviderForExcel(ITestNGMethod testNGMethod){
        try{
            Map<String, Object> params=((TestNGScenario) testNGMethod).getMetaData();
            System.out.println(("PARAMS"+params.toString()));
            Object[][] map=ExcelUtil.getDataFromxlsx(String.valueOf(ConfigurationManager.getBundle().getSubstitutor().replace(params.get(ExcelUtil.ExcelUtilParams.dataFile.name()))),String.valueOf(ConfigurationManager.getBundle().getSubstitutor().replace(params.get(ExcelUtil.ExcelUtilParams.sheet.name()))),String.valueOf(params.get(ExcelUtil.ExcelUtilParams.key.name())));
            return map;
        }catch (Throwable var){
            Throwable e=var;
            throw new AutomationError(e);
        }
    }
}
