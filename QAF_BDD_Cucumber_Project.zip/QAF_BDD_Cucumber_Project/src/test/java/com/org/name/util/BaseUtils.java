package com.org.name.util;

import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static java.sql.DriverManager.getDriver;

public class BaseUtils {

    public static QAFWebElement getWebElement(WebDriver driver,String locator, String value){
        String elementLocator= locator.replaceAll("'%VARIABLE%'",value);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2000));
        By byLocator = By.xpath(elementLocator);
        wait.until(ExpectedConditions.visibilityOfElementLocated(byLocator));
        return (QAFWebElement) driver.findElement(By.xpath(elementLocator));
    }

    public static QAFWebElement getDynamicWebElement(WebDriver driver, String locator, String value) {
        String elementLocator = locator.replace("%TEXT%", value);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2000));
        By byLocator = By.xpath(elementLocator);
        wait.until(ExpectedConditions.visibilityOfElementLocated(byLocator));
        return (QAFWebElement) driver.findElement(byLocator);
    }

    public static QAFWebElement getTableDynamicWebElement(WebElement driver, String locator, String rowIndex, String columnName){
        String elementLocator= locator.replaceAll("'%VARIABLE%'",rowIndex).replaceAll("'%TEXT%'",columnName);
        return (QAFWebElement) driver.findElement(By.xpath(elementLocator));
    }

    public static void switchToFrame(WebDriver driver, QAFWebElement frameElement) {
        frameElement.waitForPresent(20000);// Wait until the frame is present
        driver.switchTo().frame(frameElement);
    }

    public static boolean isElementPresent(QAFWebElement ele) {
        try {
            // Wait up to 5 seconds for the element to be visible
            ele.waitForVisible(5000);
            return ele.isDisplayed();
        } catch (Exception e) {
            // Element not found or not visible within the timeout
            return false;
        }
    }

    public static boolean isFramePresent(QAFWebElement frameEle) {
        try {
            // Wait up to 5 seconds for the frame element to be present and visible
            frameEle.waitForVisible(5000);
            return frameEle.isDisplayed();
        } catch (Exception e) {
            // Frame element not found or not visible within the timeout
            return false;
        }
    }

    public static void clickElement(QAFWebElement ele) {
        ele.waitForVisible(20000);
        ele.click();
    }

    public static void assertText(QAFWebElement ele, String expectedText){
        ele.waitForVisible(20000);
        String actualText = ele.getText().trim();
        System.out.println(actualText);
        if(!actualText.equals(expectedText)){
            throw new AssertionError("Test assertion failed! Expected: '" + expectedText + "', but found: '" + actualText + "'");
        }
    }

    public static void assertAttributeValue(QAFWebElement ele, String attributeName, String expectedValue) {
        ele.waitForVisible(20000); // Waits up to 20 seconds for the element to be visible
        String actualValue = ele.getAttribute(attributeName);
        System.out.println("Actual Attribute Value: " + actualValue);

        if (!actualValue.equals(expectedValue)) {
            throw new AssertionError("Test assertion failed! Expected attribute '" + attributeName + "' to be: '" + expectedValue + "', but found: '" + actualValue + "'");
        }
    }

    public static void enterText(QAFWebElement ele, String text) {
        ele.waitForVisible(20000);
        ele.click();
        ele.clear();
        ele.sendKeys(text);
        ele.waitForVisible(10000);
    }

    public static void enterTab(QAFWebElement ele){
        ele.waitForVisible(20000);
        ele.sendKeys(Keys.TAB);
    }

    public static void selectOption(QAFWebElement ele, String visibleText) {
        ele.waitForVisible(20000);
        Select select = new Select(ele);
        select.selectByVisibleText(visibleText);
    }

    public static void moveToElement(WebDriver driver,QAFWebElement ele) {
        Actions actions=new Actions(driver);
        actions.moveToElement(ele).build().perform();
    }

    public static void moveToElementAndSendKeys(WebDriver driver, QAFWebElement ele, String keysToSend) {
        Actions actions = new Actions(driver);
        actions.moveToElement(ele)
                .click()
                .sendKeys(keysToSend)
                .build()
                .perform();
    }

    public static void mouseClick(WebDriver driver,QAFWebElement ele) {
        Actions actions=new Actions(driver);
        actions.moveToElement(ele).build().perform();
        actions.click(ele).build().perform();
    }

    public static void jsClick(WebDriver driver,QAFWebElement element){
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("arguments[0].click();", element);

    }
    public static void jsScrollDown(WebDriver driver,String coordinate){
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,"+coordinate+")");
    }
    public static void jsScrollUp(WebDriver driver,String coordinate){
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(0,-"+coordinate+")");
    }
    public static void jsScrollDown(WebDriver driver){
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
    }
    public static void jsScrollUp(WebDriver driver){
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("window.scrollTo(0, -document.body.scrollHeight);");
    }

    public void waitFor(long milliseconds){
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
