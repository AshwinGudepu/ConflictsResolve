package com.org.name.util;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DataUtility {
    public static ArrayList<Object> readDataFromExternalFile(String fileName,String sheetName,String itemOption)
    {
        ArrayList<Object> dataList=new ArrayList<>();
        String excelFilePath = System.getProperty("user.dir")+"\\resources\\testdata\\"+fileName+".xlsx";
        //"path/to/journalData.xlsx"; // Update this path

        try (FileInputStream fis = new FileInputStream(new File(excelFilePath));
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet(sheetName);
            Map<String, Integer> columnMap = new HashMap<>();

            // Read header row
            Row headerRow = sheet.getRow(0);
            for (Cell cell : headerRow) {
                columnMap.put(cell.getStringCellValue(), cell.getColumnIndex());
            }

            // Example: Read values by column name
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                switch (itemOption){
                      case "testcase2":
                       break;
                }
                switch (itemOption){
                    case "testcase1":

                        break;
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return dataList;
    }


    private static String getCellValue(Cell cell) {
        if (cell == null) return "";
        switch (cell.getCellType()) {
            case STRING: return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    return String.valueOf(cell.getNumericCellValue());
                }
            case BOOLEAN: return String.valueOf(cell.getBooleanCellValue());
            default: return "";
        }
    }


}
